package com.inventory.DTO;

/**
 * Data Transfer Object (DTO) class for Users
 */
public class UserDTO {

    private int ID;
    private String fullName;
    private String location;
    private String phone;
    private String username;
    private String password;
    private String userType;
    private String inTime;
    private String outTime;

    // Default Constructor
    public UserDTO() {
    }

    // Parameterized Constructor
    public UserDTO(int ID, String fullName, String location, String phone, String username, String password, String userType, String inTime, String outTime) {
        this.ID = ID;
        this.fullName = fullName;
        this.location = location;
        this.phone = phone;
        this.username = username;
        this.password = password;
        this.userType = userType;
        this.inTime = inTime;
        this.outTime = outTime;
    }

    // Getters and Setters
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getInTime() {
        return inTime;
    }

    public void setInTime(String inTime) {
        this.inTime = inTime;
    }

    public String getOutTime() {
        return outTime;
    }

    public void setOutTime(String outTime) {
        this.outTime = outTime;
    }

    // toString() method for debugging
    @Override
    public String toString() {
        return "UserDTO{" +
                "ID=" + ID +
                ", fullName='" + fullName + '\'' +
                ", location='" + location + '\'' +
                ", phone='" + phone + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", userType='" + userType + '\'' +
                ", inTime='" + inTime + '\'' +
                ", outTime='" + outTime + '\'' +
                '}';
    }
}
