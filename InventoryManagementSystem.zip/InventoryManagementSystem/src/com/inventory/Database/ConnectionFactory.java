
package com.inventory.Database;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

/**
 * Class to retrieve connection for database and login verification.
 */
public class ConnectionFactory {

    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/inventory";
    private static String username = "root";
    private static String password = "root";

    private Properties prop;
    private Connection conn = null;

    public ConnectionFactory() {
        try {
            prop = new Properties();
            try (FileInputStream fis = new FileInputStream("lib/DBCredentials.xml")) {
                prop.loadFromXML(fis);
                username = prop.getProperty("username", username);
                password = prop.getProperty("password", password);
            } catch (IOException e) {
                System.err.println("Warning: DBCredentials.xml not found. Using default credentials.");
            }

            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, username, password);
            System.out.println("Connected successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Connection getConn() {
        try {
            if (conn == null || conn.isClosed()) {
                Class.forName(DRIVER);
                conn = DriverManager.getConnection(URL, username, password);
                System.out.println("Connected successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    // Login verification method using PreparedStatement
    public boolean checkLogin(String username, String password, String userType) {
        String query = "SELECT * FROM users WHERE username=? AND password=? AND usertype=? LIMIT 1";
        try (Connection connection = getConn();
             PreparedStatement prepStatement = connection.prepareStatement(query)) {

            prepStatement.setString(1, username);
            prepStatement.setString(2, password);
            prepStatement.setString(3, userType);

            try (ResultSet resultSet = prepStatement.executeQuery()) {
                return resultSet.next();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}

